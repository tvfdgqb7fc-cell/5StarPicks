# 5 Star Picks v2 — Full Setup Guide

## What This Is
- Public app: users see today's picks, full card, tracker
- Admin panel: you log in at yoursite.com/admin and push picks live
- Database: Supabase stores everything — record updates automatically
- No code editing ever again

---

## Step 1 — Create Your Supabase Database (Free)

1. Go to **supabase.com** → sign up free
2. Click "New Project" → name it "5starpicks" → set a database password → Create
3. Wait ~2 minutes for it to spin up
4. Go to **SQL Editor** (left sidebar) → New Query
5. Copy the entire contents of **SUPABASE_SETUP.sql** (included in this folder)
6. Paste it into the editor → click **Run**
7. This creates all your tables and seeds the pick history ✅

Get your keys:
- Go to **Settings → API**
- Copy **Project URL** → this is your `SUPABASE_URL`
- Copy **anon public key** → this is your `SUPABASE_ANON_KEY`

---

## Step 2 — Deploy to Vercel (Free)

1. Go to **github.com** → New Repository → name it "5starpicks" → Create
2. Upload all files from this folder into the repo
3. Go to **vercel.com** → sign up with GitHub → New Project → Import your repo
4. Before clicking Deploy, click **Environment Variables** and add:
   - `REACT_APP_SUPABASE_URL` = your Supabase URL
   - `REACT_APP_SUPABASE_ANON_KEY` = your anon key
   - `REACT_APP_ADMIN_PASSWORD` = your chosen password (default: 5star2026)
5. Click **Deploy** → done ✅

Your live URLs:
- **Public app:** https://5starpicks.vercel.app
- **Admin panel:** https://5starpicks.vercel.app/admin

---

## Step 3 — Install on Your Phone (PWA)

iPhone:
1. Open your URL in Safari
2. Tap Share → Add to Home Screen → Add
3. App icon appears — opens full screen like a native app

Android:
1. Open in Chrome → tap 3-dot menu → Add to Home Screen

---

## Daily Workflow (5 minutes total)

### Morning — Post Today's Picks:
1. Chat with Claude → get today's 5-star analysis
2. Open **yoursite.com/admin** on your phone
3. Fill in: date, summary, 5-star picks, full card, avoid games
4. Tap **Save** → pushes live to all users instantly ✅

### After Games — Record Results:
1. Open **yoursite.com/admin**
2. Tap **Add Result** tab
3. Enter the pick, W/L, score, breakdown
4. Tap Save → tracker and record update automatically ✅

---

## Custom Domain (~$12/year)

1. Buy **5starpicks.com** at namecheap.com
2. In Vercel → Settings → Domains → Add domain
3. Update DNS at Namecheap (Vercel walks you through it)
4. Live in 10 minutes

---

## Changing Your Password

In Vercel dashboard → Settings → Environment Variables → Update `REACT_APP_ADMIN_PASSWORD` → Redeploy

---

## File Structure
```
5starpicks-v2/
├── public/
│   ├── index.html          # PWA meta tags
│   ├── manifest.json       # App install config
│   ├── service-worker.js   # Offline support
│   ├── icon-192.png        # App icon
│   └── icon-512.png        # Splash icon
├── src/
│   ├── App.js              # Public app (reads from Supabase)
│   ├── supabase.js         # Database connection
│   ├── index.js            # Entry point
│   └── pages/
│       └── Admin.js        # Admin panel (/admin route)
├── SUPABASE_SETUP.sql      # Run this once in Supabase
├── .env.example            # Copy to .env.local with your keys
├── vercel.json
├── netlify.toml
├── package.json
└── README.md
```
