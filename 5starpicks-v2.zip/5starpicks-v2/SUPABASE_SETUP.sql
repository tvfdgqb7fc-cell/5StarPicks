-- Run this entire SQL block in your Supabase SQL editor
-- supabase.com → your project → SQL Editor → New Query → paste this → Run

-- ─── DAILY SLATE TABLE ───────────────────────────────────────────────────
-- Stores today's picks, full card, and slate summary
CREATE TABLE IF NOT EXISTS daily_slate (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  date date NOT NULL UNIQUE,
  summary text,
  streak text DEFAULT 'W1',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- ─── FIVE STAR PICKS TABLE ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS five_star_picks (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  slate_date date NOT NULL REFERENCES daily_slate(date) ON DELETE CASCADE,
  rank integer NOT NULL,
  pick text NOT NULL,
  full_name text NOT NULL,
  opponent text NOT NULL,
  opponent_full text NOT NULL,
  stars integer DEFAULT 5,
  game_time text,
  venue text,
  our_pitcher text,
  our_stats text,
  their_pitcher text,
  their_stats text,
  weather text,
  weather_ok boolean DEFAULT true,
  series_context text,
  key_edge text,
  full_breakdown text,
  caveat text,
  created_at timestamptz DEFAULT now()
);

-- ─── FULL CARD TABLE ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS full_card (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  slate_date date NOT NULL REFERENCES daily_slate(date) ON DELETE CASCADE,
  rank integer NOT NULL,
  pick text NOT NULL,
  opponent text NOT NULL,
  stars integer NOT NULL,
  game_time text,
  weather_flag text,
  reason text,
  created_at timestamptz DEFAULT now()
);

-- ─── AVOID GAMES TABLE ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS avoid_games (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  slate_date date NOT NULL REFERENCES daily_slate(date) ON DELETE CASCADE,
  game text NOT NULL,
  reason text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- ─── PICK HISTORY TABLE ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pick_history (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  pick_date date NOT NULL,
  pick text NOT NULL,
  result text NOT NULL CHECK (result IN ('W', 'L', 'P')),
  score text,
  stars integer DEFAULT 5,
  breakdown text,
  created_at timestamptz DEFAULT now()
);

-- ─── FEATURED 4-STAR TABLE ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS featured_four_star (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  slate_date date NOT NULL REFERENCES daily_slate(date) ON DELETE CASCADE,
  full_name text NOT NULL,
  opponent_full text NOT NULL,
  game_time text,
  venue text,
  our_pitcher text,
  our_stats text,
  their_pitcher text,
  their_stats text,
  weather text,
  key_edge text,
  why_not_five text,
  lineup text,
  park text,
  full_breakdown text,
  caveat text,
  created_at timestamptz DEFAULT now()
);

-- ─── ENABLE ROW LEVEL SECURITY ───────────────────────────────────────────
-- Public can read everything
ALTER TABLE daily_slate ENABLE ROW LEVEL SECURITY;
ALTER TABLE five_star_picks ENABLE ROW LEVEL SECURITY;
ALTER TABLE full_card ENABLE ROW LEVEL SECURITY;
ALTER TABLE avoid_games ENABLE ROW LEVEL SECURITY;
ALTER TABLE pick_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE featured_four_star ENABLE ROW LEVEL SECURITY;

-- Read policies (anyone can read)
CREATE POLICY "Public read daily_slate" ON daily_slate FOR SELECT USING (true);
CREATE POLICY "Public read five_star_picks" ON five_star_picks FOR SELECT USING (true);
CREATE POLICY "Public read full_card" ON full_card FOR SELECT USING (true);
CREATE POLICY "Public read avoid_games" ON avoid_games FOR SELECT USING (true);
CREATE POLICY "Public read pick_history" ON pick_history FOR SELECT USING (true);
CREATE POLICY "Public read featured_four_star" ON featured_four_star FOR SELECT USING (true);

-- Write policies (only authenticated users — your admin account)
CREATE POLICY "Auth write daily_slate" ON daily_slate FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Auth write five_star_picks" ON five_star_picks FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Auth write full_card" ON full_card FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Auth write avoid_games" ON avoid_games FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Auth write pick_history" ON pick_history FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Auth write featured_four_star" ON featured_four_star FOR ALL USING (auth.role() = 'authenticated');

-- ─── SEED PICK HISTORY ───────────────────────────────────────────────────
INSERT INTO pick_history (pick_date, pick, result, score, stars, breakdown) VALUES
('2026-04-17', 'DET over BOS', 'W', '4-1',  5, 'Valdez (3.07 FIP) vs Crochet (7.58 ERA). Crochet rocked for 11 runs in 1.2 IP. Valdez elite GB rate. Every variable clean.'),
('2026-04-18', 'SEA over TEX', 'W', '7-3',  5, 'Woo (.233 wOBA/4.2% barrel%) at T-Mobile. Most pitcher-friendly park in baseball. Woo Statcast elite on every metric.'),
('2026-04-18', 'ATL over PHI', 'W', '3-1',  5, 'Sale (3.27 ERA) + MLB #1 lineup vs PHI 5.00 ERA rotation. ATL led baseball in ERA and RBIs.'),
('2026-04-19', 'DET over BOS', 'W', '6-2',  5, 'Valdez vs Crochet again — same mismatch, same result. BOS 8-12, spiraling. Valdez dominant again.'),
('2026-04-19', 'SEA over TEX', 'W', '5-2',  5, 'Woo elite contact suppression held second straight game. T-Mobile suppressed everything.'),
('2026-04-20', 'ATL over WSH', 'W', '9-4',  5, 'Elder (0.77 ERA/1.7% barrel%!) vs Irvin (6.16 ERA/5.09 xERA). Elder barrel rate generationally elite.'),
('2026-04-20', 'SEA over ATH', 'L', '4-6',  5, 'Hancock elite through 6. Bullpen imploded after he exited. Right pick, wrong bullpen.'),
('2026-04-21', 'LAD over SF',  'L', '1-3',  5, 'Star inflation — 4-star called a 5. Roupp had been solid, SF had series momentum.'),
('2026-04-21', 'ATL over WSH', 'L', '4-11', 5, 'Formula broken — used team record as primary driver instead of pitcher quality. WSH won 11-4.'),
('2026-04-21', 'CHC over PHI', 'W', '7-4',  5, 'Imanaga (2.55 xERA) vs Luzardo. CHC swept series. Wrigley home field. PHI dead offense.'),
('2026-04-22', 'LAA over TOR', 'W', '7-3',  5, 'Soriano (0.33 ERA/.170 wOBA/30.9% Hard Hit%) most dominant Statcast profile on slate. Both sides verified.'),
('2026-04-22', 'PIT over TEX', 'W', '8-4',  5, 'Ashcraft (0 ER/11.1 IP) vs Leiter (8 ER/7 BB in 9.1 IP). Command collapse catastrophic.'),
('2026-04-23', 'DET over MIL', 'W', '5-4',  5, 'Skubal (#1 SP/2.08 ERA/.255 wOBA/6.4% barrel%) vs Sproat (8 ER/10 H/3 HR in 9.2 IP).'),
('2026-04-24', 'CLE over TOR', 'W', '8-6',  5, 'Williams (2.12 ERA/3.50 xERA/12.1 K/9) vs Scherzer (7.16 ERA/6.10 xERA). Dome. Both sides verified.'),
('2026-04-24', 'CWS over WSH', 'W', '5-4',  5, 'Fedde (3.92/3.58 xERA) vs Mikolas (19 ER/22 H/5 HR in 12.1 IP). Historic mismatch.'),
('2026-04-25', 'BAL over BOS', 'L', '1-17', 5, 'Rogers (1.89 ERA) collapsed in 1.2 IP. BAL bullpen gave up 14 more. Missed checking recent workload and bullpen state.'),
('2026-04-26', 'SEA over STL', 'W', '3-2',  5, 'Woo (wOBA .227/xwOBA .253/5.6% barrel%) vs Pallante (xwOBA .367/9.1% barrel%). Both sides verified.'),
('2026-04-27', 'TOR over BOS', 'L', '0-5',  5, 'Cease (0% barrel/xwOBA .263) vs Suarez (xwOBA .350). Formula correct. TOR offense gave zero support.'),
('2026-04-27', 'NYY over TEX', 'W', '4-2',  5, 'Fried (8 shutout IP) vs Leiter (.415 wOBA vs LHH/5.27 FIP). NYY LHH lineup exploited weakness.'),
('2026-04-28', 'CIN over COL', 'W', '7-2',  5, 'Burns (2.21 xERA/44.4% whiff — 99th pct) vs Sugano (6.04 xERA). Dome. Regression arrived on schedule.')
ON CONFLICT DO NOTHING;
