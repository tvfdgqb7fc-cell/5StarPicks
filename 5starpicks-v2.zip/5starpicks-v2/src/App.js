import { useState, useEffect } from "react";
import { supabase } from "./supabase";
import Admin from "./pages/Admin";

const STAR_COLOR = { 5:"#22c55e", 4:"#84cc16", 3:"#eab308", 2:"#f97316", 1:"#ef4444" };
const STAR_LABEL = { 5:"ELITE", 4:"STRONG", 3:"DECENT", 2:"LEAN", 1:"AVOID" };

function Stars({ n, size=13 }) {
  return (
    <div style={{display:"flex",alignItems:"center",gap:3}}>
      {[1,2,3,4,5].map(i=>(
        <span key={i} style={{fontSize:size,color:i<=n?STAR_COLOR[n]:"#1e2535",lineHeight:1}}>★</span>
      ))}
      <span style={{fontSize:9,fontWeight:800,letterSpacing:".1em",marginLeft:4,color:STAR_COLOR[n],textTransform:"uppercase"}}>{STAR_LABEL[n]}</span>
    </div>
  );
}

function WxPill({ wx }) {
  const c = wx&&wx.includes("🔴")?"#ef4444":wx&&wx.includes("⚠️")?"#eab308":"#22c55e";
  return <span style={{fontSize:10,padding:"2px 8px",borderRadius:10,background:`${c}20`,color:c,border:`1px solid ${c}40`,whiteSpace:"nowrap"}}>{wx||"✅"}</span>;
}

function ConfBadge({ stars }) {
  const c = STAR_COLOR[stars];
  return (
    <div style={{display:"inline-flex",alignItems:"center",gap:6,background:`${c}18`,border:`1px solid ${c}35`,borderRadius:8,padding:"4px 10px"}}>
      <div style={{width:7,height:7,borderRadius:"50%",background:c}}/>
      <span style={{fontSize:10,fontWeight:700,color:c,letterSpacing:".1em",textTransform:"uppercase"}}>{STAR_LABEL[stars]}</span>
      <span style={{fontSize:11,color:c}}>{[1,2,3,4,5].map(i=>i<=stars?"★":"☆").join("")}</span>
    </div>
  );
}

export default function App() {
  // Route to admin if /admin in URL
  if (window.location.pathname === '/admin') return <Admin />;

  const [tab, setTab]           = useState("picks");
  const [loading, setLoading]   = useState(true);
  const [openPick, setOpenPick] = useState(0);
  const [open4Star, setOpen4Star] = useState(false);
  const [openHist, setOpenHist] = useState(null);

  // Data from Supabase
  const [slate, setSlate]       = useState(null);
  const [picks, setPicks]       = useState([]);
  const [fourStar, setFourStar] = useState(null);
  const [card, setCard]         = useState([]);
  const [avoids, setAvoids]     = useState([]);
  const [history, setHistory]   = useState([]);
  const [record, setRecord]     = useState({ W:0, L:0, pct:0 });

  const todayDate = new Date().toISOString().split('T')[0];

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    setLoading(true);
    try {
      // Load today's slate
      const { data: slateData } = await supabase
        .from('daily_slate').select('*').eq('date', todayDate).single();
      setSlate(slateData);

      // Load 5-star picks
      const { data: picksData } = await supabase
        .from('five_star_picks').select('*').eq('slate_date', todayDate).order('rank');
      setPicks(picksData || []);

      // Load featured 4-star
      const { data: fourData } = await supabase
        .from('featured_four_star').select('*').eq('slate_date', todayDate).single();
      setFourStar(fourData);

      // Load full card
      const { data: cardData } = await supabase
        .from('full_card').select('*').eq('slate_date', todayDate).order('rank');
      setCard(cardData || []);

      // Load avoid games
      const { data: avoidData } = await supabase
        .from('avoid_games').select('*').eq('slate_date', todayDate);
      setAvoids(avoidData || []);

      // Load full history
      const { data: histData } = await supabase
        .from('pick_history').select('*').order('pick_date', { ascending: false });
      setHistory(histData || []);

      // Calculate record
      const wins   = (histData||[]).filter(h=>h.result==='W').length;
      const losses = (histData||[]).filter(h=>h.result==='L').length;
      const total  = wins + losses;
      setRecord({ W: wins, L: losses, pct: total > 0 ? Math.round(wins/total*100) : 0 });

    } catch (e) {
      console.error('Load error:', e);
    }
    setLoading(false);
  };

  const streak = slate?.streak || 'W1';
  const dateLabel = slate ? new Date(slate.date + 'T12:00:00').toLocaleDateString('en-US', { weekday:'long', year:'numeric', month:'long', day:'numeric' }) : new Date().toLocaleDateString('en-US', { weekday:'long', year:'numeric', month:'long', day:'numeric' });

  return (
    <div style={{minHeight:"100vh",background:"linear-gradient(160deg,#070d1a 0%,#0b1525 55%,#08111e 100%)",fontFamily:"'Inter',system-ui,sans-serif",color:"#cdd8ee"}}>
      <div style={{position:"fixed",inset:0,pointerEvents:"none",zIndex:0,backgroundImage:"linear-gradient(rgba(255,255,255,.018) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.018) 1px,transparent 1px)",backgroundSize:"44px 44px"}}/>

      {/* HEADER */}
      <header style={{position:"sticky",top:0,zIndex:100,background:"rgba(7,13,26,.94)",backdropFilter:"blur(16px)",borderBottom:"1px solid rgba(34,197,94,.14)"}}>
        <div style={{maxWidth:1060,margin:"0 auto",padding:"14px 20px",display:"flex",alignItems:"center",justifyContent:"space-between",flexWrap:"wrap",gap:12}}>
          <div style={{display:"flex",alignItems:"center",gap:14}}>
            <div style={{width:52,height:52,borderRadius:14,flexShrink:0,background:"linear-gradient(135deg,#22c55e,#15803d)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:26,boxShadow:"0 0 28px rgba(34,197,94,.4)"}}>⭐</div>
            <div>
              <div style={{fontSize:24,fontWeight:900,letterSpacing:".06em",textTransform:"uppercase",background:"linear-gradient(90deg,#22c55e,#86efac)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",lineHeight:1}}>5 Star Picks</div>
              <div style={{fontSize:10,color:"#2d4a6a",letterSpacing:".24em",textTransform:"uppercase",marginTop:3}}>MLB · Daily Analysis Engine</div>
            </div>
          </div>
          <div style={{display:"flex",gap:10}}>
            <div style={{background:"rgba(34,197,94,.07)",border:"1px solid rgba(34,197,94,.18)",borderRadius:12,padding:"10px 20px",textAlign:"center",minWidth:100}}>
              <div style={{fontSize:9,color:"#2d4a6a",letterSpacing:".2em",textTransform:"uppercase",marginBottom:3}}>5★ Record</div>
              <div style={{display:"flex",gap:7,alignItems:"baseline",justifyContent:"center"}}>
                <span style={{fontSize:26,fontWeight:900,color:"#22c55e",lineHeight:1}}>{record.W}-{record.L}</span>
                <span style={{fontSize:13,color:"#86efac"}}>{record.pct}%</span>
              </div>
            </div>
            <div style={{background:"rgba(234,179,8,.07)",border:"1px solid rgba(234,179,8,.18)",borderRadius:12,padding:"10px 20px",textAlign:"center",minWidth:76}}>
              <div style={{fontSize:9,color:"#2d4a6a",letterSpacing:".2em",textTransform:"uppercase",marginBottom:3}}>Streak</div>
              <div style={{fontSize:26,fontWeight:900,color:"#eab308",lineHeight:1}}>{streak}</div>
            </div>
          </div>
        </div>
        <div style={{background:"rgba(34,197,94,.04)",borderTop:"1px solid rgba(34,197,94,.07)",padding:"5px 20px",textAlign:"center"}}>
          <span style={{fontSize:10,color:"#2d4a6a",letterSpacing:".22em",textTransform:"uppercase"}}>📅 {dateLabel}</span>
        </div>
        <div style={{maxWidth:1060,margin:"0 auto",padding:"0 20px",display:"flex"}}>
          {[{id:"picks",label:"⭐ Today's Picks"},{id:"card",label:"📋 Full Card"},{id:"tracker",label:"📊 Tracker"}].map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{background:"none",border:"none",cursor:"pointer",padding:"12px 18px",fontSize:11,letterSpacing:".1em",textTransform:"uppercase",fontFamily:"inherit",fontWeight:tab===t.id?700:400,color:tab===t.id?"#22c55e":"#2d4a6a",borderBottom:tab===t.id?"2px solid #22c55e":"2px solid transparent",transition:"color .15s",whiteSpace:"nowrap"}}>{t.label}</button>
          ))}
        </div>
      </header>

      <main style={{maxWidth:1060,margin:"0 auto",padding:"28px 20px",position:"relative",zIndex:5}}>

        {/* Loading */}
        {loading && (
          <div style={{textAlign:"center",padding:"80px 0"}}>
            <div style={{fontSize:40,marginBottom:16,animation:"spin 1.5s linear infinite"}}>⭐</div>
            <div style={{fontSize:16,color:"#22c55e",letterSpacing:".1em",textTransform:"uppercase",marginBottom:8}}>Loading Picks</div>
            <div style={{fontSize:12,color:"#3d5a7a"}}>Pulling today's analysis...</div>
            <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
          </div>
        )}

        {!loading && (
          <>
            {/* Slate banner */}
            {slate?.summary && (
              <div style={{background:"rgba(34,197,94,.05)",border:"1px solid rgba(34,197,94,.12)",borderRadius:12,padding:"14px 18px",marginBottom:26,display:"flex",gap:12,alignItems:"flex-start"}}>
                <span style={{fontSize:17,flexShrink:0,marginTop:1}}>📊</span>
                <p style={{margin:0,color:"#7aadcc",lineHeight:1.75,fontSize:13}}><strong style={{color:"#86efac"}}>Slate Overview: </strong>{slate.summary}</p>
              </div>
            )}

            {/* TAB: PICKS */}
            {tab==="picks" && (
              <div>
                <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:18}}>
                  <div style={{background:"linear-gradient(135deg,#22c55e,#15803d)",color:"#fff",padding:"5px 16px",borderRadius:20,fontSize:10,fontWeight:800,letterSpacing:".1em",textTransform:"uppercase",boxShadow:"0 2px 14px rgba(34,197,94,.32)"}}>
                    {picks.length>0?`${picks.length} Five-Star Pick${picks.length!==1?"s":""} Today`:"Today's Picks Pending"}
                  </div>
                  <span style={{fontSize:11,color:"#2d4a6a"}}>ERA · xERA · Statcast · Weather — all verified</span>
                </div>

                {picks.length===0 && !loading && (
                  <div style={{textAlign:"center",padding:"60px 20px",border:"1px dashed rgba(34,197,94,.15)",borderRadius:14,background:"rgba(34,197,94,.03)",marginBottom:24}}>
                    <div style={{fontSize:40,marginBottom:14}}>⏳</div>
                    <div style={{fontSize:16,fontWeight:700,color:"#22c55e",marginBottom:8}}>Analysis In Progress</div>
                    <div style={{fontSize:13,color:"#3d5a7a",lineHeight:1.7}}>Picks are posted once all 5-star criteria are fully verified. Check back shortly.</div>
                  </div>
                )}

                <div style={{display:"flex",flexDirection:"column",gap:14}}>
                  {picks.map((p,i)=>{
                    const isOpen = openPick===i;
                    return (
                      <div key={i} style={{border:`1px solid ${isOpen?"rgba(34,197,94,.3)":"rgba(255,255,255,.07)"}`,borderRadius:14,overflow:"hidden",background:isOpen?"rgba(34,197,94,.05)":"rgba(255,255,255,.025)",boxShadow:isOpen?"0 4px 32px rgba(34,197,94,.08)":"none",transition:"all .2s"}}>
                        <div onClick={()=>setOpenPick(isOpen?null:i)} style={{padding:"18px 20px",cursor:"pointer"}}>
                          <div style={{display:"flex",alignItems:"flex-start",gap:14,flexWrap:"wrap"}}>
                            <div style={{width:44,height:44,borderRadius:12,flexShrink:0,background:"linear-gradient(135deg,#22c55e,#16a34a)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:17,fontWeight:900,color:"#fff",boxShadow:"0 0 16px rgba(34,197,94,.3)"}}>#{p.rank}</div>
                            <div style={{flex:1,minWidth:170}}>
                              <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap",marginBottom:6}}>
                                <span style={{fontSize:20,fontWeight:800,color:"#e2eefc"}}>{p.full_name}</span>
                                <span style={{fontSize:12,color:"#3d5a7a"}}>over</span>
                                <span style={{fontSize:14,color:"#5a7a9a"}}>{p.opponent_full}</span>
                              </div>
                              <div style={{display:"flex",alignItems:"center",gap:10,flexWrap:"wrap"}}>
                                <Stars n={5} size={15}/>
                                <span style={{fontSize:11,color:"#3d5a7a"}}>{p.game_time} · {p.venue}</span>
                              </div>
                            </div>
                            <div style={{background:"rgba(34,197,94,.08)",border:"1px solid rgba(34,197,94,.18)",borderRadius:10,padding:"8px 14px",maxWidth:230}}>
                              <div style={{fontSize:9,color:"#3d5a7a",textTransform:"uppercase",letterSpacing:".12em",marginBottom:3}}>Key Edge</div>
                              <div style={{fontSize:11,color:"#86efac",lineHeight:1.5}}>{p.key_edge}</div>
                            </div>
                            <span style={{fontSize:16,color:"#2a3a50",marginLeft:"auto",alignSelf:"center"}}>{isOpen?"▲":"▼"}</span>
                          </div>
                        </div>
                        <div style={{background:"rgba(0,0,0,.25)",padding:"11px 20px",display:"flex",gap:14,alignItems:"center",flexWrap:"wrap",borderTop:"1px solid rgba(255,255,255,.04)"}}>
                          <div style={{flex:1,minWidth:130}}>
                            <div style={{fontSize:9,color:"#22c55e",textTransform:"uppercase",letterSpacing:".12em",marginBottom:2}}>✅ Our Pitcher</div>
                            <div style={{fontSize:14,fontWeight:700,color:"#22c55e"}}>{p.our_pitcher}</div>
                            <div style={{fontSize:11,color:"#3d5a7a",marginTop:2}}>{p.our_stats}</div>
                          </div>
                          <span style={{fontSize:18,color:"#1a2540"}}>⚔</span>
                          <div style={{flex:1,minWidth:130,textAlign:"right"}}>
                            <div style={{fontSize:9,color:"#ef4444",textTransform:"uppercase",letterSpacing:".12em",marginBottom:2}}>🔴 Their Pitcher</div>
                            <div style={{fontSize:14,fontWeight:700,color:"#ef4444"}}>{p.their_pitcher}</div>
                            <div style={{fontSize:11,color:"#3d5a7a",marginTop:2}}>{p.their_stats}</div>
                          </div>
                        </div>
                        {isOpen && (
                          <div style={{padding:"18px 20px 22px",borderTop:"1px solid rgba(34,197,94,.09)"}}>
                            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}>
                              <div style={{background:"rgba(0,0,0,.2)",borderRadius:9,padding:"11px 14px"}}>
                                <div style={{fontSize:9,color:"#3d5a7a",textTransform:"uppercase",letterSpacing:".12em",marginBottom:4}}>🌤 Weather</div>
                                <div style={{fontSize:12,color:p.weather_ok?"#22c55e":"#fbbf24"}}>{p.weather}</div>
                              </div>
                              <div style={{background:"rgba(0,0,0,.2)",borderRadius:9,padding:"11px 14px"}}>
                                <div style={{fontSize:9,color:"#3d5a7a",textTransform:"uppercase",letterSpacing:".12em",marginBottom:4}}>📈 Series</div>
                                <div style={{fontSize:12,color:"#7aadcc"}}>{p.series_context}</div>
                              </div>
                            </div>
                            <div style={{marginBottom:14}}>
                              <div style={{fontSize:9,color:"#3d5a7a",textTransform:"uppercase",letterSpacing:".12em",marginBottom:7}}>Full Analysis</div>
                              <p style={{margin:0,fontSize:13,color:"#7aadcc",lineHeight:1.82}}>{p.full_breakdown}</p>
                            </div>
                            <div style={{background:"rgba(251,191,36,.06)",border:"1px solid rgba(251,191,36,.18)",borderRadius:8,padding:"9px 14px"}}>
                              <span style={{fontSize:11,color:"#fbbf24"}}>⚠ Caveat: {p.caveat}</span>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Featured 4-star */}
                {fourStar && (
                  <div style={{marginTop:28}}>
                    <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:14}}>
                      <div style={{background:"rgba(132,204,22,.20)",border:"1px solid rgba(132,204,22,.40)",color:"#84cc16",padding:"4px 14px",borderRadius:20,fontSize:10,fontWeight:800,letterSpacing:".1em",textTransform:"uppercase"}}>Featured 4-Star Pick</div>
                      <span style={{fontSize:11,color:"#3d5a7a"}}>Strong edge — one criteria short of 5-star</span>
                    </div>
                    <div style={{border:"1px solid rgba(132,204,22,.30)",borderRadius:14,overflow:"hidden",background:"rgba(132,204,22,.05)"}}>
                      <div onClick={()=>setOpen4Star(!open4Star)} style={{padding:"18px 20px",cursor:"pointer"}}>
                        <div style={{display:"flex",alignItems:"flex-start",gap:14,flexWrap:"wrap"}}>
                          <div style={{width:44,height:44,borderRadius:12,flexShrink:0,background:"linear-gradient(135deg,#84cc16,#65a30d)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:900,color:"#fff"}}>★★★★</div>
                          <div style={{flex:1,minWidth:170}}>
                            <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap",marginBottom:6}}>
                              <span style={{fontSize:20,fontWeight:800,color:"#e2eefc"}}>{fourStar.full_name}</span>
                              <span style={{fontSize:12,color:"#3d5a7a"}}>over</span>
                              <span style={{fontSize:14,color:"#5a7a9a"}}>{fourStar.opponent_full}</span>
                            </div>
                            <div style={{display:"flex",alignItems:"center",gap:10,flexWrap:"wrap"}}>
                              <Stars n={4} size={15}/>
                              <span style={{fontSize:11,color:"#3d5a7a"}}>{fourStar.game_time} · {fourStar.venue}</span>
                            </div>
                          </div>
                          <div style={{background:"rgba(132,204,22,.10)",border:"1px solid rgba(132,204,22,.25)",borderRadius:10,padding:"8px 14px",maxWidth:230}}>
                            <div style={{fontSize:9,color:"#3d5a7a",textTransform:"uppercase",letterSpacing:".12em",marginBottom:3}}>Key Edge</div>
                            <div style={{fontSize:11,color:"#84cc16",lineHeight:1.5}}>{fourStar.key_edge}</div>
                          </div>
                          <span style={{fontSize:16,color:"#2a3a50",marginLeft:"auto",alignSelf:"center"}}>{open4Star?"▲":"▼"}</span>
                        </div>
                      </div>
                      <div style={{background:"rgba(0,0,0,.25)",padding:"11px 20px",display:"flex",gap:14,alignItems:"center",flexWrap:"wrap",borderTop:"1px solid rgba(255,255,255,.04)"}}>
                        <div style={{flex:1,minWidth:130}}>
                          <div style={{fontSize:9,color:"#84cc16",textTransform:"uppercase",letterSpacing:".12em",marginBottom:2}}>✅ Our Pitcher</div>
                          <div style={{fontSize:14,fontWeight:700,color:"#84cc16"}}>{fourStar.our_pitcher}</div>
                          <div style={{fontSize:11,color:"#3d5a7a",marginTop:2}}>{fourStar.our_stats}</div>
                        </div>
                        <span style={{fontSize:18,color:"#1a2540"}}>⚔</span>
                        <div style={{flex:1,minWidth:130,textAlign:"right"}}>
                          <div style={{fontSize:9,color:"#ef4444",textTransform:"uppercase",letterSpacing:".12em",marginBottom:2}}>🔴 Their Pitcher</div>
                          <div style={{fontSize:14,fontWeight:700,color:"#ef4444"}}>{fourStar.their_pitcher}</div>
                          <div style={{fontSize:11,color:"#3d5a7a",marginTop:2}}>{fourStar.their_stats}</div>
                        </div>
                      </div>
                      {open4Star && (
                        <div style={{padding:"18px 20px 22px",borderTop:"1px solid rgba(132,204,22,.12)"}}>
                          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}>
                            <div style={{background:"rgba(0,0,0,.2)",borderRadius:9,padding:"11px 14px"}}>
                              <div style={{fontSize:9,color:"#3d5a7a",textTransform:"uppercase",letterSpacing:".12em",marginBottom:4}}>🌤 Weather</div>
                              <div style={{fontSize:12,color:"#22c55e"}}>{fourStar.weather}</div>
                            </div>
                            <div style={{background:"rgba(0,0,0,.2)",borderRadius:9,padding:"11px 14px"}}>
                              <div style={{fontSize:9,color:"#3d5a7a",textTransform:"uppercase",letterSpacing:".12em",marginBottom:4}}>🏟 Park</div>
                              <div style={{fontSize:12,color:"#7aadcc"}}>{fourStar.park}</div>
                            </div>
                          </div>
                          {fourStar.lineup && (
                            <div style={{background:"rgba(0,0,0,.2)",borderRadius:9,padding:"11px 14px",marginBottom:14}}>
                              <div style={{fontSize:9,color:"#3d5a7a",textTransform:"uppercase",letterSpacing:".12em",marginBottom:4}}>💪 Lineup</div>
                              <div style={{fontSize:12,color:"#7aadcc"}}>{fourStar.lineup}</div>
                            </div>
                          )}
                          <div style={{marginBottom:14}}>
                            <div style={{fontSize:9,color:"#3d5a7a",textTransform:"uppercase",letterSpacing:".12em",marginBottom:7}}>Full Analysis</div>
                            <p style={{margin:0,fontSize:13,color:"#7aadcc",lineHeight:1.82}}>{fourStar.full_breakdown}</p>
                          </div>
                          <div style={{background:"rgba(132,204,22,.08)",border:"1px solid rgba(132,204,22,.20)",borderRadius:8,padding:"9px 14px",marginBottom:10}}>
                            <span style={{fontSize:11,color:"#84cc16"}}>⭐ Why 4-Star not 5: {fourStar.why_not_five}</span>
                          </div>
                          <div style={{background:"rgba(251,191,36,.06)",border:"1px solid rgba(251,191,36,.18)",borderRadius:8,padding:"9px 14px"}}>
                            <span style={{fontSize:11,color:"#fbbf24"}}>⚠ Caveat: {fourStar.caveat}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Avoid */}
                {avoids.length>0 && (
                  <div style={{marginTop:24}}>
                    <div style={{fontSize:10,color:"#2d4a6a",letterSpacing:".14em",textTransform:"uppercase",marginBottom:10}}>🚫 Games to Avoid Today</div>
                    {avoids.map((a,i)=>(
                      <div key={i} style={{background:"rgba(239,68,68,.05)",border:"1px solid rgba(239,68,68,.14)",borderRadius:9,padding:"10px 14px",marginBottom:6,display:"flex",gap:10,alignItems:"center",flexWrap:"wrap"}}>
                        <span style={{fontWeight:700,color:"#ef4444",fontSize:12}}>{a.game}</span>
                        <span style={{color:"#2d4a6a",fontSize:12}}>— {a.reason}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB: FULL CARD */}
            {tab==="card" && (
              <div>
                <div style={{background:"rgba(255,255,255,.03)",border:"1px solid rgba(255,255,255,.07)",borderRadius:11,padding:"13px 18px",marginBottom:18}}>
                  <div style={{fontSize:9,color:"#2d4a6a",textTransform:"uppercase",letterSpacing:".16em",marginBottom:10}}>Confidence Scale — Green = Best, Red = Worst</div>
                  <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                    {[5,4,3,2,1].map(n=>(
                      <div key={n} style={{display:"flex",alignItems:"center",gap:6,background:`${STAR_COLOR[n]}15`,border:`1px solid ${STAR_COLOR[n]}30`,borderRadius:8,padding:"5px 10px"}}>
                        <div style={{width:7,height:7,borderRadius:"50%",background:STAR_COLOR[n]}}/>
                        <span style={{fontSize:10,color:STAR_COLOR[n],fontWeight:700}}>{STAR_LABEL[n]}</span>
                        <span style={{fontSize:11,color:STAR_COLOR[n]}}>{[1,2,3,4,5].map(i=>i<=n?"★":"☆").join("")}</span>
                      </div>
                    ))}
                  </div>
                </div>
                {card.length===0 && <div style={{textAlign:"center",padding:"40px",color:"#3d5a7a",fontSize:13}}>Full card will appear once today's slate is loaded.</div>}
                <div style={{display:"flex",flexDirection:"column",gap:6}}>
                  {card.map((g,i)=>{
                    const c = STAR_COLOR[g.stars];
                    return (
                      <div key={i} style={{background:`${c}08`,border:`1px solid ${c}22`,borderRadius:10,padding:"12px 16px",display:"flex",alignItems:"center",gap:10,flexWrap:"wrap",borderLeft:`4px solid ${c}`}}>
                        <span style={{fontSize:11,color:"#2d4a6a",width:22,textAlign:"center",flexShrink:0,fontWeight:700}}>{g.rank}</span>
                        <ConfBadge stars={g.stars}/>
                        <div style={{minWidth:140,flex:"0 0 auto"}}>
                          <span style={{fontSize:14,fontWeight:700,color:"#e0ecfc"}}>{g.pick}</span>
                          <span style={{fontSize:12,color:"#2d4a6a"}}> over {g.opponent}</span>
                        </div>
                        <span style={{fontSize:10,color:"#2d4a6a",flexShrink:0}}>{g.game_time}</span>
                        <span style={{fontSize:11,color:"#4a6a88",flex:1,minWidth:160}}>{g.reason}</span>
                        <WxPill wx={g.weather_flag}/>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB: TRACKER */}
            {tab==="tracker" && (
              <div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:14,marginBottom:26}}>
                  {[
                    {label:"Record",   value:`${record.W}-${record.L}`, sub:`${history.length} picks taken`, color:"#22c55e"},
                    {label:"Win Rate", value:`${record.pct}%`,           sub:"Since Apr 17, 2026",           color:"#86efac"},
                    {label:"Streak",   value:streak,                      sub:"Current run",                 color:"#eab308"},
                  ].map((s,i)=>(
                    <div key={i} style={{background:"rgba(255,255,255,.03)",border:"1px solid rgba(255,255,255,.07)",borderRadius:12,padding:"20px 16px",textAlign:"center"}}>
                      <div style={{fontSize:9,color:"#2d4a6a",letterSpacing:".18em",textTransform:"uppercase",marginBottom:7}}>{s.label}</div>
                      <div style={{fontSize:34,fontWeight:900,color:s.color,lineHeight:1}}>{s.value}</div>
                      <div style={{fontSize:10,color:"#1e3050",marginTop:6}}>{s.sub}</div>
                    </div>
                  ))}
                </div>
                <div style={{background:"rgba(34,197,94,.04)",border:"1px solid rgba(34,197,94,.1)",borderRadius:11,padding:"13px 18px",marginBottom:24}}>
                  <div style={{fontSize:9,color:"#2d4a6a",textTransform:"uppercase",letterSpacing:".16em",marginBottom:9}}>5-Star Formula — All 5 Criteria Must Be Met</div>
                  <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                    {["ERA + xERA Aligned","Statcast Verified","Opponent Confirmed Broken","Weather Under 30%","Not Coors Field"].map((x,i)=>(
                      <span key={i} style={{background:"rgba(34,197,94,.07)",border:"1px solid rgba(34,197,94,.14)",borderRadius:12,padding:"3px 10px",fontSize:11,color:"#86efac"}}>✓ {x}</span>
                    ))}
                  </div>
                </div>
                <div style={{fontSize:10,color:"#2d4a6a",letterSpacing:".16em",textTransform:"uppercase",marginBottom:12}}>
                  Complete Pick History — {history.length} picks · tap any row for breakdown
                </div>
                <div style={{display:"flex",flexDirection:"column",gap:6}}>
                  {history.map((h,i)=>{
                    const isOpen = openHist===i;
                    const win = h.result==="W";
                    const wc = win?"#22c55e":"#ef4444";
                    return (
                      <div key={i} style={{border:`1px solid ${isOpen?`${wc}28`:"rgba(255,255,255,.05)"}`,borderRadius:10,overflow:"hidden",background:isOpen?`${wc}06`:"rgba(255,255,255,.02)",transition:"all .15s"}}>
                        <div onClick={()=>setOpenHist(isOpen?null:i)} style={{padding:"11px 16px",cursor:"pointer",display:"flex",alignItems:"center",gap:10,flexWrap:"wrap",borderLeft:`3px solid ${wc}`}}>
                          <div style={{width:30,height:30,borderRadius:"50%",flexShrink:0,background:`${wc}18`,border:`1px solid ${wc}35`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:900,color:wc}}>{h.result}</div>
                          <span style={{fontSize:11,color:"#3d5a7a",width:56,flexShrink:0}}>{new Date(h.pick_date+'T12:00:00').toLocaleDateString('en-US',{month:'short',day:'numeric'})}</span>
                          <span style={{fontSize:13,fontWeight:600,flex:1,minWidth:150,color:win?"#cdd8ee":"#4a6a88"}}>{h.pick}</span>
                          {h.score&&<span style={{fontSize:13,fontWeight:800,color:wc,flexShrink:0}}>{h.score}</span>}
                          <div style={{display:"flex",gap:1,flexShrink:0}}>{[1,2,3,4,5].map(idx=><span key={idx} style={{fontSize:11,color:idx<=h.stars?STAR_COLOR[h.stars]:"#1e2535"}}>★</span>)}</div>
                          <span style={{fontSize:11,color:"#2a3a50",flexShrink:0}}>{isOpen?"▲":"▼"}</span>
                        </div>
                        {isOpen&&(
                          <div style={{padding:"12px 16px 16px",borderTop:`1px solid ${wc}12`}}>
                            <p style={{margin:0,fontSize:13,color:"#4a6a88",lineHeight:1.82}}>{h.breakdown}</p>
                            {!win&&<div style={{marginTop:10,background:"rgba(239,68,68,.06)",border:"1px solid rgba(239,68,68,.15)",borderRadius:7,padding:"8px 12px"}}><span style={{fontSize:11,color:"#ef4444"}}>📌 Loss reviewed to maintain formula discipline.</span></div>}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}
      </main>

      <footer style={{borderTop:"1px solid rgba(34,197,94,.07)",padding:"18px 20px",textAlign:"center",marginTop:20}}>
        <span style={{fontSize:10,color:"#162030",letterSpacing:".18em",textTransform:"uppercase"}}>5 Star Picks · MLB Analysis Engine · For Entertainment Purposes Only</span>
      </footer>
    </div>
  );
}
