import { useState, useEffect } from 'react';
import { supabase } from '../supabase';

const I = (style) => ({ ...style });

export default function Admin() {
  const [authed, setAuthed]       = useState(false);
  const [password, setPassword]   = useState('');
  const [loading, setLoading]     = useState(false);
  const [saving, setSaving]       = useState(false);
  const [msg, setMsg]             = useState('');
  const [activeTab, setActiveTab] = useState('slate');

  // Slate
  const today = new Date().toISOString().split('T')[0];
  const [date, setDate]           = useState(today);
  const [summary, setSummary]     = useState('');
  const [streak, setStreak]       = useState('W1');

  // 5-star picks (up to 3)
  const emptyPick = { rank:1, pick:'', full_name:'', opponent:'', opponent_full:'', stars:5, game_time:'', venue:'', our_pitcher:'', our_stats:'', their_pitcher:'', their_stats:'', weather:'', weather_ok:true, series_context:'', key_edge:'', full_breakdown:'', caveat:'' };
  const [picks, setPicks]         = useState([{...emptyPick}]);

  // Featured 4-star
  const [has4Star, setHas4Star]   = useState(false);
  const [fourStar, setFourStar]   = useState({ full_name:'', opponent_full:'', game_time:'', venue:'', our_pitcher:'', our_stats:'', their_pitcher:'', their_stats:'', weather:'', key_edge:'', why_not_five:'', lineup:'', park:'', full_breakdown:'', caveat:'' });

  // Full card (all ranked games)
  const emptyGame = { rank:1, pick:'', opponent:'', stars:3, game_time:'', weather_flag:'✅ Clean', reason:'' };
  const [card, setCard]           = useState([{...emptyGame}]);

  // Avoid games
  const [avoids, setAvoids]       = useState([{ game:'', reason:'' }]);

  // History entry
  const [histDate, setHistDate]   = useState(today);
  const [histPick, setHistPick]   = useState('');
  const [histResult, setHistResult] = useState('W');
  const [histScore, setHistScore] = useState('');
  const [histBreakdown, setHistBreakdown] = useState('');

  const ADMIN_PASSWORD = process.env.REACT_APP_ADMIN_PASSWORD || '5star2026';

  const login = () => {
    if (password === ADMIN_PASSWORD) { setAuthed(true); setMsg(''); }
    else setMsg('Wrong password');
  };

  const flash = (m) => { setMsg(m); setTimeout(() => setMsg(''), 3000); };

  const saveSlate = async () => {
    setSaving(true);
    try {
      // Upsert daily slate
      const { error: slateErr } = await supabase.from('daily_slate').upsert({ date, summary, streak }, { onConflict: 'date' });
      if (slateErr) throw slateErr;

      // Delete existing picks for this date then insert fresh
      await supabase.from('five_star_picks').delete().eq('slate_date', date);
      if (picks.filter(p => p.pick).length > 0) {
        const { error: picksErr } = await supabase.from('five_star_picks').insert(
          picks.filter(p => p.pick).map(p => ({ ...p, slate_date: date }))
        );
        if (picksErr) throw picksErr;
      }

      // Featured 4-star
      await supabase.from('featured_four_star').delete().eq('slate_date', date);
      if (has4Star && fourStar.full_name) {
        await supabase.from('featured_four_star').insert({ ...fourStar, slate_date: date });
      }

      // Full card
      await supabase.from('full_card').delete().eq('slate_date', date);
      if (card.filter(g => g.pick).length > 0) {
        await supabase.from('full_card').insert(
          card.filter(g => g.pick).map(g => ({ ...g, slate_date: date }))
        );
      }

      // Avoid games
      await supabase.from('avoid_games').delete().eq('slate_date', date);
      if (avoids.filter(a => a.game).length > 0) {
        await supabase.from('avoid_games').insert(
          avoids.filter(a => a.game).map(a => ({ ...a, slate_date: date }))
        );
      }

      flash('✅ Slate saved! App updated live for all users.');
    } catch (e) {
      flash(`❌ Error: ${e.message}`);
    }
    setSaving(false);
  };

  const saveHistory = async () => {
    setSaving(true);
    try {
      const { error } = await supabase.from('pick_history').insert({
        pick_date: histDate, pick: histPick, result: histResult,
        score: histScore, stars: 5, breakdown: histBreakdown
      });
      if (error) throw error;
      flash('✅ Result saved to history!');
      setHistPick(''); setHistScore(''); setHistBreakdown('');
    } catch (e) {
      flash(`❌ Error: ${e.message}`);
    }
    setSaving(false);
  };

  const updatePick = (i, field, val) => {
    const next = [...picks];
    next[i] = { ...next[i], [field]: val };
    setPicks(next);
  };

  const updateCard = (i, field, val) => {
    const next = [...card];
    next[i] = { ...next[i], [field]: val };
    setCard(next);
  };

  const inputStyle = { width:'100%', background:'rgba(255,255,255,.06)', border:'1px solid rgba(255,255,255,.12)', borderRadius:8, padding:'10px 12px', color:'#cdd8ee', fontSize:13, fontFamily:'inherit', outline:'none', marginBottom:8 };
  const labelStyle = { fontSize:10, color:'#3d5a7a', textTransform:'uppercase', letterSpacing:'.12em', display:'block', marginBottom:4 };
  const sectionStyle = { background:'rgba(255,255,255,.03)', border:'1px solid rgba(255,255,255,.07)', borderRadius:12, padding:'18px', marginBottom:16 };

  if (!authed) return (
    <div style={{ minHeight:'100vh', background:'#070d1a', display:'flex', alignItems:'center', justifyContent:'center', fontFamily:'Inter,sans-serif' }}>
      <div style={{ background:'rgba(255,255,255,.04)', border:'1px solid rgba(34,197,94,.2)', borderRadius:16, padding:'40px 32px', width:320, textAlign:'center' }}>
        <div style={{ fontSize:40, marginBottom:16 }}>⭐</div>
        <div style={{ fontSize:20, fontWeight:800, color:'#22c55e', marginBottom:8, textTransform:'uppercase', letterSpacing:'.06em' }}>Admin Panel</div>
        <div style={{ fontSize:12, color:'#3d5a7a', marginBottom:24 }}>5 Star Picks · Staff Only</div>
        <input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} onKeyDown={e=>e.key==='Enter'&&login()}
          style={{ ...inputStyle, textAlign:'center', fontSize:16, letterSpacing:'.2em' }}/>
        <button onClick={login} style={{ width:'100%', background:'linear-gradient(135deg,#22c55e,#15803d)', color:'#fff', border:'none', borderRadius:8, padding:'12px', fontSize:13, fontWeight:700, cursor:'pointer', letterSpacing:'.08em', textTransform:'uppercase' }}>
          Enter
        </button>
        {msg && <div style={{ color:'#ef4444', fontSize:12, marginTop:12 }}>{msg}</div>}
      </div>
    </div>
  );

  return (
    <div style={{ minHeight:'100vh', background:'#070d1a', fontFamily:'Inter,sans-serif', color:'#cdd8ee', paddingBottom:60 }}>
      {/* Header */}
      <div style={{ background:'rgba(7,13,26,.95)', borderBottom:'1px solid rgba(34,197,94,.15)', padding:'14px 20px', display:'flex', alignItems:'center', justifyContent:'space-between', position:'sticky', top:0, zIndex:50 }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <span style={{ fontSize:22 }}>⭐</span>
          <div>
            <div style={{ fontSize:16, fontWeight:800, color:'#22c55e', letterSpacing:'.04em', textTransform:'uppercase' }}>5 Star Picks</div>
            <div style={{ fontSize:10, color:'#3d5a7a', letterSpacing:'.16em', textTransform:'uppercase' }}>Admin Panel</div>
          </div>
        </div>
        <button onClick={()=>setAuthed(false)} style={{ background:'rgba(239,68,68,.1)', color:'#ef4444', border:'1px solid rgba(239,68,68,.2)', borderRadius:8, padding:'6px 14px', fontSize:11, cursor:'pointer', fontFamily:'inherit' }}>
          Sign Out
        </button>
      </div>

      {/* Flash message */}
      {msg && (
        <div style={{ background: msg.includes('✅') ? 'rgba(34,197,94,.12)' : 'rgba(239,68,68,.12)', border: `1px solid ${msg.includes('✅') ? 'rgba(34,197,94,.3)' : 'rgba(239,68,68,.3)'}`, color: msg.includes('✅') ? '#22c55e' : '#ef4444', padding:'12px 20px', textAlign:'center', fontSize:13, fontWeight:600 }}>
          {msg}
        </div>
      )}

      <div style={{ maxWidth:800, margin:'0 auto', padding:'24px 16px' }}>
        {/* Tabs */}
        <div style={{ display:'flex', gap:0, marginBottom:24, background:'rgba(255,255,255,.03)', borderRadius:10, padding:4 }}>
          {[{id:'slate',label:'📋 Today\'s Slate'},{id:'history',label:'📊 Add Result'},{id:'guide',label:'📖 Guide'}].map(t=>(
            <button key={t.id} onClick={()=>setActiveTab(t.id)} style={{ flex:1, background:activeTab===t.id?'rgba(34,197,94,.15)':'none', border:activeTab===t.id?'1px solid rgba(34,197,94,.25)':'1px solid transparent', borderRadius:8, padding:'10px', fontSize:12, fontWeight:activeTab===t.id?700:400, color:activeTab===t.id?'#22c55e':'#3d5a7a', cursor:'pointer', fontFamily:'inherit', letterSpacing:'.06em', textTransform:'uppercase' }}>
              {t.label}
            </button>
          ))}
        </div>

        {/* TAB: SLATE */}
        {activeTab==='slate' && (
          <div>
            {/* Date + Summary */}
            <div style={sectionStyle}>
              <div style={{ fontSize:13, fontWeight:700, color:'#86efac', marginBottom:14, textTransform:'uppercase', letterSpacing:'.08em' }}>📅 Slate Info</div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:12 }}>
                <div>
                  <label style={labelStyle}>Date</label>
                  <input type="date" value={date} onChange={e=>setDate(e.target.value)} style={inputStyle}/>
                </div>
                <div>
                  <label style={labelStyle}>Current Streak</label>
                  <input placeholder="e.g. W3" value={streak} onChange={e=>setStreak(e.target.value)} style={inputStyle}/>
                </div>
              </div>
              <label style={labelStyle}>Slate Summary</label>
              <textarea placeholder="Brief overview of today's slate..." value={summary} onChange={e=>setSummary(e.target.value)} rows={3} style={{...inputStyle, resize:'vertical'}}/>
            </div>

            {/* 5-Star Picks */}
            <div style={sectionStyle}>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14 }}>
                <div style={{ fontSize:13, fontWeight:700, color:'#22c55e', textTransform:'uppercase', letterSpacing:'.08em' }}>⭐ 5-Star Picks</div>
                <button onClick={()=>setPicks([...picks,{...emptyPick,rank:picks.length+1}])} style={{ background:'rgba(34,197,94,.12)', color:'#22c55e', border:'1px solid rgba(34,197,94,.25)', borderRadius:6, padding:'5px 12px', fontSize:11, cursor:'pointer', fontFamily:'inherit' }}>
                  + Add Pick
                </button>
              </div>
              {picks.map((p,i)=>(
                <div key={i} style={{ background:'rgba(34,197,94,.04)', border:'1px solid rgba(34,197,94,.12)', borderRadius:10, padding:'14px', marginBottom:12 }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
                    <span style={{ fontSize:12, fontWeight:700, color:'#22c55e' }}>Pick #{i+1}</span>
                    {picks.length>1 && <button onClick={()=>setPicks(picks.filter((_,idx)=>idx!==i))} style={{ background:'rgba(239,68,68,.1)', color:'#ef4444', border:'none', borderRadius:5, padding:'3px 8px', fontSize:10, cursor:'pointer' }}>Remove</button>}
                  </div>
                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
                    <div><label style={labelStyle}>Our Team (abbrev)</label><input placeholder="e.g. NYM" value={p.pick} onChange={e=>updatePick(i,'pick',e.target.value)} style={inputStyle}/></div>
                    <div><label style={labelStyle}>Full Team Name</label><input placeholder="e.g. New York Mets" value={p.full_name} onChange={e=>updatePick(i,'full_name',e.target.value)} style={inputStyle}/></div>
                    <div><label style={labelStyle}>Opponent (abbrev)</label><input placeholder="e.g. WSH" value={p.opponent} onChange={e=>updatePick(i,'opponent',e.target.value)} style={inputStyle}/></div>
                    <div><label style={labelStyle}>Opponent Full Name</label><input placeholder="e.g. Washington Nationals" value={p.opponent_full} onChange={e=>updatePick(i,'opponent_full',e.target.value)} style={inputStyle}/></div>
                    <div><label style={labelStyle}>Game Time</label><input placeholder="e.g. 6:10 PM CT" value={p.game_time} onChange={e=>updatePick(i,'game_time',e.target.value)} style={inputStyle}/></div>
                    <div><label style={labelStyle}>Venue</label><input placeholder="e.g. Nationals Park" value={p.venue} onChange={e=>updatePick(i,'venue',e.target.value)} style={inputStyle}/></div>
                    <div><label style={labelStyle}>Our Pitcher</label><input placeholder="e.g. Nolan McLean" value={p.our_pitcher} onChange={e=>updatePick(i,'our_pitcher',e.target.value)} style={inputStyle}/></div>
                    <div><label style={labelStyle}>Our Pitcher Stats</label><input placeholder="e.g. 1.94 xERA · elite" value={p.our_stats} onChange={e=>updatePick(i,'our_stats',e.target.value)} style={inputStyle}/></div>
                    <div><label style={labelStyle}>Their Pitcher</label><input placeholder="e.g. Cade Cavalli" value={p.their_pitcher} onChange={e=>updatePick(i,'their_pitcher',e.target.value)} style={inputStyle}/></div>
                    <div><label style={labelStyle}>Their Pitcher Stats</label><input placeholder="e.g. 5.4 BB/9 — broken" value={p.their_stats} onChange={e=>updatePick(i,'their_stats',e.target.value)} style={inputStyle}/></div>
                    <div><label style={labelStyle}>Weather</label><input placeholder="e.g. Dome ✅ or 72°F, 0% rain" value={p.weather} onChange={e=>updatePick(i,'weather',e.target.value)} style={inputStyle}/></div>
                    <div style={{ display:'flex', alignItems:'center', gap:8, paddingTop:20 }}>
                      <input type="checkbox" checked={p.weather_ok} onChange={e=>updatePick(i,'weather_ok',e.target.checked)} style={{ width:16, height:16 }}/>
                      <label style={{ ...labelStyle, marginBottom:0 }}>Weather Safe</label>
                    </div>
                  </div>
                  <div><label style={labelStyle}>Key Edge (1 line)</label><input placeholder="e.g. McLean's 1.94 xERA is elite. Cavalli walks everyone." value={p.key_edge} onChange={e=>updatePick(i,'key_edge',e.target.value)} style={inputStyle}/></div>
                  <div><label style={labelStyle}>Series Context</label><input placeholder="e.g. NYM visiting WSH, McLean has been rock solid" value={p.series_context} onChange={e=>updatePick(i,'series_context',e.target.value)} style={inputStyle}/></div>
                  <div><label style={labelStyle}>Full Breakdown (3-4 sentences)</label><textarea placeholder="Detailed analysis..." value={p.full_breakdown} onChange={e=>updatePick(i,'full_breakdown',e.target.value)} rows={4} style={{...inputStyle,resize:'vertical'}}/></div>
                  <div><label style={labelStyle}>Caveat</label><input placeholder="e.g. NYM offense is inconsistent..." value={p.caveat} onChange={e=>updatePick(i,'caveat',e.target.value)} style={inputStyle}/></div>
                </div>
              ))}
            </div>

            {/* Featured 4-Star */}
            <div style={sectionStyle}>
              <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:14 }}>
                <div style={{ fontSize:13, fontWeight:700, color:'#84cc16', textTransform:'uppercase', letterSpacing:'.08em' }}>★★★★ Featured 4-Star</div>
                <label style={{ display:'flex', alignItems:'center', gap:6, cursor:'pointer' }}>
                  <input type="checkbox" checked={has4Star} onChange={e=>setHas4Star(e.target.checked)} style={{ width:16, height:16 }}/>
                  <span style={{ fontSize:11, color:'#3d5a7a' }}>Include today</span>
                </label>
              </div>
              {has4Star && (
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
                  <div><label style={labelStyle}>Team Full Name</label><input placeholder="e.g. Los Angeles Dodgers" value={fourStar.full_name} onChange={e=>setFourStar({...fourStar,full_name:e.target.value})} style={inputStyle}/></div>
                  <div><label style={labelStyle}>Opponent Full Name</label><input placeholder="e.g. Miami Marlins" value={fourStar.opponent_full} onChange={e=>setFourStar({...fourStar,opponent_full:e.target.value})} style={inputStyle}/></div>
                  <div><label style={labelStyle}>Game Time</label><input value={fourStar.game_time} onChange={e=>setFourStar({...fourStar,game_time:e.target.value})} style={inputStyle}/></div>
                  <div><label style={labelStyle}>Venue</label><input value={fourStar.venue} onChange={e=>setFourStar({...fourStar,venue:e.target.value})} style={inputStyle}/></div>
                  <div><label style={labelStyle}>Our Pitcher</label><input value={fourStar.our_pitcher} onChange={e=>setFourStar({...fourStar,our_pitcher:e.target.value})} style={inputStyle}/></div>
                  <div><label style={labelStyle}>Our Stats</label><input value={fourStar.our_stats} onChange={e=>setFourStar({...fourStar,our_stats:e.target.value})} style={inputStyle}/></div>
                  <div><label style={labelStyle}>Their Pitcher</label><input value={fourStar.their_pitcher} onChange={e=>setFourStar({...fourStar,their_pitcher:e.target.value})} style={inputStyle}/></div>
                  <div><label style={labelStyle}>Their Stats</label><input value={fourStar.their_stats} onChange={e=>setFourStar({...fourStar,their_stats:e.target.value})} style={inputStyle}/></div>
                  <div style={{ gridColumn:'1/-1' }}><label style={labelStyle}>Key Edge</label><input value={fourStar.key_edge} onChange={e=>setFourStar({...fourStar,key_edge:e.target.value})} style={inputStyle}/></div>
                  <div style={{ gridColumn:'1/-1' }}><label style={labelStyle}>Why 4-Star Not 5</label><input value={fourStar.why_not_five} onChange={e=>setFourStar({...fourStar,why_not_five:e.target.value})} style={inputStyle}/></div>
                  <div style={{ gridColumn:'1/-1' }}><label style={labelStyle}>Lineup Advantage</label><input value={fourStar.lineup} onChange={e=>setFourStar({...fourStar,lineup:e.target.value})} style={inputStyle}/></div>
                  <div style={{ gridColumn:'1/-1' }}><label style={labelStyle}>Park & Conditions</label><input value={fourStar.park} onChange={e=>setFourStar({...fourStar,park:e.target.value})} style={inputStyle}/></div>
                  <div style={{ gridColumn:'1/-1' }}><label style={labelStyle}>Full Breakdown</label><textarea value={fourStar.full_breakdown} onChange={e=>setFourStar({...fourStar,full_breakdown:e.target.value})} rows={4} style={{...inputStyle,resize:'vertical'}}/></div>
                  <div style={{ gridColumn:'1/-1' }}><label style={labelStyle}>Caveat</label><input value={fourStar.caveat} onChange={e=>setFourStar({...fourStar,caveat:e.target.value})} style={inputStyle}/></div>
                </div>
              )}
            </div>

            {/* Full Card */}
            <div style={sectionStyle}>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14 }}>
                <div style={{ fontSize:13, fontWeight:700, color:'#cdd8ee', textTransform:'uppercase', letterSpacing:'.08em' }}>📋 Full Ranked Card</div>
                <button onClick={()=>setCard([...card,{...emptyGame,rank:card.length+1}])} style={{ background:'rgba(255,255,255,.08)', color:'#cdd8ee', border:'1px solid rgba(255,255,255,.15)', borderRadius:6, padding:'5px 12px', fontSize:11, cursor:'pointer', fontFamily:'inherit' }}>
                  + Add Game
                </button>
              </div>
              {card.map((g,i)=>(
                <div key={i} style={{ display:'grid', gridTemplateColumns:'40px 60px 60px 60px 80px 80px 1fr 30px', gap:6, alignItems:'center', marginBottom:8 }}>
                  <input type="number" value={g.rank} onChange={e=>updateCard(i,'rank',parseInt(e.target.value))} style={{...inputStyle,textAlign:'center',marginBottom:0,padding:'8px 4px'}} placeholder="#"/>
                  <input value={g.pick} onChange={e=>updateCard(i,'pick',e.target.value)} style={{...inputStyle,marginBottom:0,padding:'8px 6px'}} placeholder="Team"/>
                  <input value={g.opponent} onChange={e=>updateCard(i,'opponent',e.target.value)} style={{...inputStyle,marginBottom:0,padding:'8px 6px'}} placeholder="Opp"/>
                  <select value={g.stars} onChange={e=>updateCard(i,'stars',parseInt(e.target.value))} style={{...inputStyle,marginBottom:0,padding:'8px 4px'}}>
                    {[5,4,3,2,1].map(n=><option key={n} value={n}>{n}★</option>)}
                  </select>
                  <input value={g.game_time} onChange={e=>updateCard(i,'game_time',e.target.value)} style={{...inputStyle,marginBottom:0,padding:'8px 6px'}} placeholder="Time"/>
                  <input value={g.weather_flag} onChange={e=>updateCard(i,'weather_flag',e.target.value)} style={{...inputStyle,marginBottom:0,padding:'8px 6px'}} placeholder="Wx"/>
                  <input value={g.reason} onChange={e=>updateCard(i,'reason',e.target.value)} style={{...inputStyle,marginBottom:0,padding:'8px 8px'}} placeholder="One-line reason..."/>
                  {card.length>1 && <button onClick={()=>setCard(card.filter((_,idx)=>idx!==i))} style={{ background:'rgba(239,68,68,.1)', color:'#ef4444', border:'none', borderRadius:5, padding:'8px 6px', fontSize:11, cursor:'pointer' }}>✕</button>}
                </div>
              ))}
            </div>

            {/* Avoid */}
            <div style={sectionStyle}>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14 }}>
                <div style={{ fontSize:13, fontWeight:700, color:'#ef4444', textTransform:'uppercase', letterSpacing:'.08em' }}>🚫 Games to Avoid</div>
                <button onClick={()=>setAvoids([...avoids,{game:'',reason:''}])} style={{ background:'rgba(239,68,68,.1)', color:'#ef4444', border:'1px solid rgba(239,68,68,.2)', borderRadius:6, padding:'5px 12px', fontSize:11, cursor:'pointer', fontFamily:'inherit' }}>
                  + Add
                </button>
              </div>
              {avoids.map((a,i)=>(
                <div key={i} style={{ display:'grid', gridTemplateColumns:'1fr 2fr 30px', gap:8, marginBottom:8 }}>
                  <input value={a.game} onChange={e=>{const n=[...avoids];n[i]={...n[i],game:e.target.value};setAvoids(n);}} style={{...inputStyle,marginBottom:0}} placeholder="e.g. TB @ CLE"/>
                  <input value={a.reason} onChange={e=>{const n=[...avoids];n[i]={...n[i],reason:e.target.value};setAvoids(n);}} style={{...inputStyle,marginBottom:0}} placeholder="Reason..."/>
                  {avoids.length>1 && <button onClick={()=>setAvoids(avoids.filter((_,idx)=>idx!==i))} style={{ background:'rgba(239,68,68,.1)', color:'#ef4444', border:'none', borderRadius:5, cursor:'pointer' }}>✕</button>}
                </div>
              ))}
            </div>

            {/* Save button */}
            <button onClick={saveSlate} disabled={saving} style={{ width:'100%', background: saving ? 'rgba(34,197,94,.3)' : 'linear-gradient(135deg,#22c55e,#15803d)', color:'#fff', border:'none', borderRadius:12, padding:'16px', fontSize:14, fontWeight:800, cursor: saving ? 'not-allowed' : 'pointer', letterSpacing:'.08em', textTransform:'uppercase', boxShadow:'0 4px 20px rgba(34,197,94,.3)' }}>
              {saving ? 'Saving...' : '✅ Save — Push Live to All Users'}
            </button>
          </div>
        )}

        {/* TAB: ADD RESULT */}
        {activeTab==='history' && (
          <div>
            <div style={sectionStyle}>
              <div style={{ fontSize:13, fontWeight:700, color:'#86efac', marginBottom:14, textTransform:'uppercase', letterSpacing:'.08em' }}>📊 Add Pick Result to History</div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
                <div><label style={labelStyle}>Date</label><input type="date" value={histDate} onChange={e=>setHistDate(e.target.value)} style={inputStyle}/></div>
                <div>
                  <label style={labelStyle}>Result</label>
                  <select value={histResult} onChange={e=>setHistResult(e.target.value)} style={inputStyle}>
                    <option value="W">✅ Win</option>
                    <option value="L">❌ Loss</option>
                    <option value="P">⏸ Push</option>
                  </select>
                </div>
                <div style={{ gridColumn:'1/-1' }}><label style={labelStyle}>Pick (e.g. "NYM over WSH")</label><input value={histPick} onChange={e=>setHistPick(e.target.value)} style={inputStyle}/></div>
                <div><label style={labelStyle}>Score</label><input placeholder="e.g. 4-2" value={histScore} onChange={e=>setHistScore(e.target.value)} style={inputStyle}/></div>
              </div>
              <label style={labelStyle}>Breakdown / Post-mortem</label>
              <textarea placeholder="Why we won or why we lost — be honest..." value={histBreakdown} onChange={e=>setHistBreakdown(e.target.value)} rows={4} style={{...inputStyle,resize:'vertical'}}/>
              <button onClick={saveHistory} disabled={saving||!histPick} style={{ width:'100%', background: saving||!histPick ? 'rgba(34,197,94,.2)' : 'linear-gradient(135deg,#22c55e,#15803d)', color:'#fff', border:'none', borderRadius:10, padding:'14px', fontSize:13, fontWeight:800, cursor: saving||!histPick ? 'not-allowed' : 'pointer', textTransform:'uppercase', letterSpacing:'.08em' }}>
                {saving ? 'Saving...' : 'Save Result'}
              </button>
            </div>
          </div>
        )}

        {/* TAB: GUIDE */}
        {activeTab==='guide' && (
          <div style={sectionStyle}>
            <div style={{ fontSize:13, fontWeight:700, color:'#86efac', marginBottom:16, textTransform:'uppercase', letterSpacing:'.08em' }}>📖 Daily Workflow</div>
            {[
              { step:'1', title:'Get the picks from Claude', desc:'Paste your daily prompt into Claude. Get the 5-star analysis with confirmed starters, Statcast, and weather.' },
              { step:'2', title:'Fill in Today\'s Slate tab', desc:'Enter the date, summary, 5-star picks, full card, and avoid games. Takes about 5 minutes.' },
              { step:'3', title:'Hit Save', desc:'One button push. App updates live for every user instantly. No GitHub. No code.' },
              { step:'4', title:'After the game — Add Result', desc:'Go to the Add Result tab. Enter the score and a quick breakdown. Tracker updates automatically.' },
            ].map((s,i)=>(
              <div key={i} style={{ display:'flex', gap:14, marginBottom:16 }}>
                <div style={{ width:32, height:32, borderRadius:'50%', background:'linear-gradient(135deg,#22c55e,#15803d)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:14, fontWeight:900, color:'#fff', flexShrink:0 }}>{s.step}</div>
                <div>
                  <div style={{ fontSize:13, fontWeight:700, color:'#cdd8ee', marginBottom:4 }}>{s.title}</div>
                  <div style={{ fontSize:12, color:'#3d5a7a', lineHeight:1.6 }}>{s.desc}</div>
                </div>
              </div>
            ))}
            <div style={{ background:'rgba(255,215,0,.06)', border:'1px solid rgba(255,215,0,.15)', borderRadius:8, padding:'12px 14px', marginTop:8 }}>
              <div style={{ fontSize:11, color:'#fbbf24', lineHeight:1.7 }}>
                <strong>Default password:</strong> 5star2026<br/>
                Change it by setting <code>REACT_APP_ADMIN_PASSWORD</code> in your Vercel environment variables.
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
